import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF075e54);
const kPrimaryLightColor = Color(0xFFF1E6FF);
const background = Color(0xFFdcf8c6);
const button = Color(0xFF34B7F1);
String Departmant = "NULL";
String Date = "NULL";
String Position="0";

int currqnum=0 ;

int ans = 0;
int t1;